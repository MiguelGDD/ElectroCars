prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 28506
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>45001813632535674908
,p_default_application_id=>28506
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PBDMIGUEL'
);
wwv_flow_api.create_app_setting(
 p_id=>wwv_flow_api.id(10585227673333752584)
,p_name=>'FEEDBACK_ATTACHMENTS_YN'
,p_value=>'Y'
,p_is_required=>'N'
,p_valid_values=>'Y, N'
,p_on_upgrade_keep_value=>true
,p_required_patch=>wwv_flow_api.id(10585225011830752581)
);
wwv_flow_api.component_end;
end;
/
