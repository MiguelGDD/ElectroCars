prompt --application/shared_components/navigation/lists/interfaz_de_usuario
begin
--   Manifest
--     LIST: Interfaz de Usuario
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>45001813632535674908
,p_default_application_id=>28506
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PBDMIGUEL'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(10585489075490753340)
,p_name=>'Interfaz de Usuario'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_api.id(10585225648546752581)
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10585489438061753340)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Selecci\00F3n de estilo de tema')
,p_list_item_link_target=>'f?p=&APP_ID.:10020:&SESSION.::&DEBUG.:10020:::'
,p_list_item_icon=>'fa-paint-brush'
,p_list_text_01=>unistr('Definir la interfaz de usuario por defecto de la aplicaci\00F3n')
,p_required_patch=>wwv_flow_api.id(10585225648546752581)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
