prompt --application/shared_components/navigation/lists/configuración_de_la_aplicación
begin
--   Manifest
--     LIST: Configuración de la Aplicación
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>45001813632535674908
,p_default_application_id=>28506
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PBDMIGUEL'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(10585488350169753340)
,p_name=>unistr('Configuraci\00F3n de la Aplicaci\00F3n')
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_api.id(10585225216373752581)
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10585488711642753340)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Opciones de Configuraci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:10010:&SESSION.::&DEBUG.:10010:::'
,p_list_item_icon=>'fa-sliders'
,p_list_text_01=>unistr('Activar o desactivar funciones de la aplicaci\00F3n')
,p_required_patch=>wwv_flow_api.id(10585225216373752581)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
