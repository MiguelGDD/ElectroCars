prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>45001813632535674908
,p_default_application_id=>28506
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PBDMIGUEL'
);
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_api.id(10585223438235752576)
,p_name=>'DETALLES DE LA COMPRA'
,p_alias=>'DETALLES-DE-LA-COMPRA'
,p_step_title=>'DETALLES DE LA COMPRA'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>Para buscar los datos, introduzca un t\00E9rmino de b\00FAsqueda en el cuadro de di\00E1logo de b\00FAsqueda o haga clic en las cabeceras de columna para limitar los registros devueltos.</p>'),
'',
unistr('<p>Puede realizar varias funciones haciendo clic en el bot\00F3n <strong>Acciones</strong>, entre las que se incluyen el seleccionar las columnas que se muestran u ocultan y su secuencia de visualizaci\00F3n, adem\00E1s de numerosas funciones de datos y formato.')
||unistr(' Tambi\00E9n puede definir m\00E1s vistas de los datos con las opciones de gr\00E1fico, agrupaci\00F3n por y giro.</p>'),
'',
unistr('<p>Si desea guardar las personalizaciones, seleccione el informe o haga clic en Descargar para descargar los datos. Introduzca la direcci\00F3n de correo electr\00F3nico y el marco temporal de la suscripci\00F3n para el env\00EDo de los datos de forma regular.<p>'),
'',
unistr('<p>Para obtener m\00E1s informaci\00F3n, haga clic en Ayuda en la parte inferior del men\00FA Acciones.</p>'),
'',
unistr('<p>Haga clic en el bot\00F3n <strong>Restablecer</strong> para restablecer la configuraci\00F3n por defecto del informe interactivo.</p>')))
,p_last_updated_by=>'MIGUEL.GUELL@UNISIMON.EDU.CO'
,p_last_upd_yyyymmddhh24miss=>'20210604022150'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10585247383772752623)
,p_plug_name=>'Compras'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10585131940155752533)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'COMPRAS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'DETALLES DE LA COMPRA'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10585247425435752623)
,p_name=>'DETALLES DE LA COMPRA'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:4:&APP_SESSION.:::4:P4_ID_COMPRA:\#ID_COMPRA#\'
,p_detail_link_text=>'<span class="fa fa-edit" aria-hidden="true"></span>'
,p_owner=>'MIGUEL.GUELL@UNISIMON.EDU.CO'
,p_internal_uid=>10585247425435752623
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585247891777752625)
,p_db_column_name=>'ID_COMPRA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id Compra'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585248200777752626)
,p_db_column_name=>'COSTO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Costo'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585248674830752626)
,p_db_column_name=>'TIPO_PAGO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Tipo Pago'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585249051440752626)
,p_db_column_name=>'FECHA_COMPRA'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Fecha Compra'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585249443200752626)
,p_db_column_name=>'FECHA_ENTREGA'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Fecha Entrega'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585249833956752627)
,p_db_column_name=>'GARANTIA'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Garantia'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585250273692752627)
,p_db_column_name=>'VENDEDOR_ID'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Vendedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_named_lov=>wwv_flow_api.id(10585252653711752630)
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585250605247752627)
,p_db_column_name=>'AUTOMOVIL_ID'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Automovil'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_named_lov=>wwv_flow_api.id(10585251490405752628)
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585251043014752627)
,p_db_column_name=>'CLIENTE_ID'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Cliente'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_named_lov=>wwv_flow_api.id(10585252071029752629)
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10585324544263752874)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'105853246'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COSTO:TIPO_PAGO:FECHA_COMPRA:FECHA_ENTREGA:GARANTIA:VENDEDOR_ID:AUTOMOVIL_ID:CLIENTE_ID'
,p_sort_column_1=>'COSTO'
,p_sort_direction_1=>'ASC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10585254074011752631)
,p_plug_name=>unistr('Ruta de Navegaci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10585143248584752539)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(10584876257663752506)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(10585200303757752565)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10585253296307752630)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(10585247383772752623)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(10585199089187752564)
,p_button_image_alt=>'Restablecer'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10585255876262752632)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(10585247383772752623)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(10585198929348752564)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Crear'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:4'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(10585254905360752632)
,p_name=>unistr('Editar Informe: Cuadro de Di\00E1logo Cerrado')
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(10585247383772752623)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10585255465877752632)
,p_event_id=>wwv_flow_api.id(10585254905360752632)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(10585247383772752623)
);
wwv_flow_api.component_end;
end;
/
